## Module <om_account_bank_statement_import>

#### 20.12.2021
#### Version 14.0.3.0.0
##### FIX
- access rights issue
